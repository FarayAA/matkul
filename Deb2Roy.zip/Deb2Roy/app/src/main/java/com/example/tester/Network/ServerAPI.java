package com.example.tester.Network;

public class ServerAPI {
    public static final String Lihat_Data = "http://nurchim.000webhostapp.com/lihatdata.php";
}
